class StationModel {
  final String id;
  final String name;
  final String address;
  final double latitude;
  final double longitude;
  final String connectorType;
  final double power;
  final String fee;
  final double rating;

  StationModel({
    required this.id,
    required this.name,
    required this.address,
    required this.latitude,
    required this.longitude,
    required this.connectorType,
    required this.power,
    required this.fee,
    required this.rating,
  });

  factory StationModel.fromMap(Map<String, dynamic> map, String id) {
    return StationModel(
      id: id,
      name: map['name'] ?? '',
      address: map['address'] ?? '',
      latitude: (map['latitude'] ?? 0).toDouble(),
      longitude: (map['longitude'] ?? 0).toDouble(),
      connectorType: map['connectorType'] ?? '',
      power: (map['power'] ?? 0).toDouble(),
      fee: map['fee'] ?? '',
      rating: (map['rating'] ?? 0).toDouble(),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'name': name,
      'address': address,
      'latitude': latitude,
      'longitude': longitude,
      'connectorType': connectorType,
      'power': power,
      'fee': fee,
      'rating': rating,
    };
  }

  @override
  String toString() {
    return 'StationModel(id: $id, name: $name, power: ${power}kW)';
  }
}
