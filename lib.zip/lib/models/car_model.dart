class CarModel {
  final String id;
  final String name;
  final String connectorType;
  final double batteryCapacity;

  CarModel({
    required this.id,
    required this.name,
    required this.connectorType,
    required this.batteryCapacity,
  });

  factory CarModel.fromMap(Map<String, dynamic> map, String id) {
    return CarModel(
      id: id,
      name: map['name'] ?? '',
      connectorType: map['connectorType'] ?? '',
      batteryCapacity: (map['batteryCapacity'] ?? 0).toDouble(),
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'name': name,
      'connectorType': connectorType,
      'batteryCapacity': batteryCapacity,
    };
  }

  @override
  String toString() {
    return 'CarModel(id: $id, name: $name, connector: $connectorType, battery: ${batteryCapacity}kWh)';
  }
}
