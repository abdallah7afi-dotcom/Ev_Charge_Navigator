import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:ev_charge_navigator/theme/app_theme.dart';
import 'package:ev_charge_navigator/services/auth_service.dart';
import 'package:ev_charge_navigator/services/firestore_service.dart';
import 'package:ev_charge_navigator/models/car_model.dart';
import 'package:ev_charge_navigator/services/station_seed_service.dart';

class AppDrawer extends StatefulWidget {
  final CarModel? primaryCar;
  final VoidCallback onDataChanged;

  const AppDrawer({
    super.key,
    this.primaryCar,
    required this.onDataChanged,
  });

  @override
  State<AppDrawer> createState() => _AppDrawerState();
}

class _AppDrawerState extends State<AppDrawer> {
  bool _showPasswordFields = false;
  bool _passwordVerified = false;
  final _oldPassController = TextEditingController();
  final _newPassController = TextEditingController();
  final _confirmPassController = TextEditingController();
  String? _passError;

  @override
  void dispose() {
    _oldPassController.dispose();
    _newPassController.dispose();
    _confirmPassController.dispose();
    super.dispose();
  }

  void _resetPasswordState() {
    setState(() {
      _showPasswordFields = false;
      _passwordVerified = false;
      _passError = null;
      _oldPassController.clear();
      _newPassController.clear();
      _confirmPassController.clear();
    });
  }

  @override
  Widget build(BuildContext context) {
    final auth = Provider.of<AuthService>(context);

    return Drawer(
      child: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header
            Container(
              width: double.infinity,
              padding: const EdgeInsets.fromLTRB(20, 28, 20, 20),
              decoration: const BoxDecoration(
                gradient: AppGradients.cardGradient,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  CircleAvatar(
                    radius: 28,
                    backgroundColor: Colors.white.withValues(alpha: 0.2),
                    child: Text(
                      auth.userName.isNotEmpty
                          ? auth.userName[0].toUpperCase()
                          : 'U',
                      style: GoogleFonts.inter(
                        fontSize: 22,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  Text(
                    auth.userName.isNotEmpty ? auth.userName : 'Driver',
                    style: GoogleFonts.inter(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    auth.user?.email ?? '',
                    style: GoogleFonts.inter(
                      fontSize: 13,
                      color: Colors.white70,
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 8),

            // Profile Section
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
              child: Text(
                'PROFILE',
                style: GoogleFonts.inter(
                  fontSize: 11,
                  fontWeight: FontWeight.w700,
                  color: AppColors.textMuted,
                  letterSpacing: 1.2,
                ),
              ),
            ),
            _buildTile(
              icon: Icons.person_outline,
              title: auth.userName.isNotEmpty ? auth.userName : 'Driver',
              onTap: null,
            ),
            _buildTile(
              icon: Icons.email_outlined,
              title: auth.user?.email ?? 'No email',
              onTap: null,
            ),
            _buildTile(
              icon: Icons.lock_outline,
              title: 'Change Password',
              onTap: () {
                setState(() {
                  _showPasswordFields = !_showPasswordFields;
                  if (!_showPasswordFields) _resetPasswordState();
                });
              },
            ),

            // Password fields (inline)
            if (_showPasswordFields)
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Column(
                  children: [
                    const SizedBox(height: 4),
                    if (!_passwordVerified) ...[
                      TextField(
                        controller: _oldPassController,
                        obscureText: true,
                        decoration: InputDecoration(
                          labelText: 'Current Password',
                          errorText: _passError,
                          isDense: true,
                        ),
                      ),
                      const SizedBox(height: 8),
                      SizedBox(
                        width: double.infinity,
                        height: 36,
                        child: ElevatedButton(
                          onPressed: () async {
                            if (_oldPassController.text.isEmpty) {
                              setState(() => _passError = 'Required');
                              return;
                            }
                            final valid = await auth
                                .verifyPassword(_oldPassController.text);
                            setState(() {
                              if (valid) {
                                _passwordVerified = true;
                                _passError = null;
                              } else {
                                _passError = 'Incorrect password';
                              }
                            });
                          },
                          style: ElevatedButton.styleFrom(
                            minimumSize: Size.zero,
                            textStyle: GoogleFonts.inter(fontSize: 13),
                          ),
                          child: const Text('Verify'),
                        ),
                      ),
                    ],
                    if (_passwordVerified) ...[
                      TextField(
                        controller: _newPassController,
                        obscureText: true,
                        decoration: const InputDecoration(
                          labelText: 'New Password',
                          isDense: true,
                        ),
                      ),
                      const SizedBox(height: 8),
                      TextField(
                        controller: _confirmPassController,
                        obscureText: true,
                        decoration: InputDecoration(
                          labelText: 'Confirm Password',
                          errorText: _passError,
                          isDense: true,
                        ),
                      ),
                      const SizedBox(height: 8),
                      SizedBox(
                        width: double.infinity,
                        height: 36,
                        child: ElevatedButton(
                          onPressed: () async {
                            if (_newPassController.text.length < 6) {
                              setState(() => _passError = 'Min 6 characters');
                              return;
                            }
                            if (_newPassController.text !=
                                _confirmPassController.text) {
                              setState(
                                  () => _passError = 'Passwords don\'t match');
                              return;
                            }
                            final ok = await auth
                                .updatePassword(_newPassController.text);
                            if (context.mounted) {
                              Navigator.pop(context);
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(
                                  content: Text(ok
                                      ? 'Password updated'
                                      : auth.errorMessage ??
                                          'Error updating'),
                                  backgroundColor: ok
                                      ? AppColors.positive
                                      : AppColors.negative,
                                ),
                              );
                            }
                          },
                          style: ElevatedButton.styleFrom(
                            minimumSize: Size.zero,
                            textStyle: GoogleFonts.inter(fontSize: 13),
                          ),
                          child: const Text('Update'),
                        ),
                      ),
                    ],
                    const SizedBox(height: 8),
                  ],
                ),
              ),

            const Divider(height: 16, indent: 16, endIndent: 16),

            // My Vehicles Section
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
              child: Text(
                'MY VEHICLES',
                style: GoogleFonts.inter(
                  fontSize: 11,
                  fontWeight: FontWeight.w700,
                  color: AppColors.textMuted,
                  letterSpacing: 1.2,
                ),
              ),
            ),
            _buildTile(
              icon: Icons.directions_car_outlined,
              title: widget.primaryCar?.name ?? 'No vehicle selected',
              onTap: () {
                Navigator.pop(context);
                Navigator.pushNamed(context, '/car-selection').then((_) {
                  widget.onDataChanged();
                });
              },
            ),

            const Divider(height: 16, indent: 16, endIndent: 16),

            // Seed Stations
            _buildTile(
              icon: Icons.cloud_upload_outlined,
              title: 'Seed Stations',
              onTap: () => _seedStations(context),
            ),

            const Spacer(),

            // Logout
            const Divider(height: 1, indent: 16, endIndent: 16),
            _buildTile(
              icon: Icons.logout,
              title: 'Logout',
              color: AppColors.negative,
              onTap: () async {
                await auth.signOut();
                if (context.mounted) {
                  Navigator.pushNamedAndRemoveUntil(
                      context, '/login', (route) => false);
                }
              },
            ),
            const SizedBox(height: 16),
          ],
        ),
      ),
    );
  }

  Widget _buildTile({
    required IconData icon,
    required String title,
    VoidCallback? onTap,
    Color? color,
  }) {
    return ListTile(
      dense: true,
      leading: Icon(icon, color: color ?? AppColors.textMuted, size: 22),
      title: Text(
        title,
        style: GoogleFonts.inter(
          fontSize: 14,
          fontWeight: FontWeight.w500,
          color: color ?? AppColors.textDark,
        ),
      ),
      trailing: onTap != null
          ? Icon(Icons.chevron_right, color: AppColors.border, size: 20)
          : null,
      onTap: onTap,
    );
  }

  Future<void> _seedStations(BuildContext context) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        title: Text('Seed Stations',
            style: GoogleFonts.inter(fontWeight: FontWeight.bold)),
        content: Text(
          'Reset and add 29 Riyadh EV stations?',
          style: GoogleFonts.inter(fontSize: 14),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: Text('Cancel',
                style: GoogleFonts.inter(color: AppColors.textMuted)),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(ctx, true),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.accent,
              minimumSize: const Size(80, 40),
            ),
            child: const Text('Seed', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );

    if (confirmed != true || !context.mounted) return;

    Navigator.pop(context); // Close drawer

    final firestoreService = FirestoreService();

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Seeding stations...'),
        duration: Duration(seconds: 30),
      ),
    );

    try {
      await firestoreService.seedStations(
        StationSeedService.riyadhStations,
        onProgress: (current, total) {
          if (context.mounted) {
            ScaffoldMessenger.of(context).hideCurrentSnackBar();
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text('Added $current / $total stations...'),
                duration: const Duration(seconds: 30),
              ),
            );
          }
        },
      );

      if (context.mounted) {
        ScaffoldMessenger.of(context).hideCurrentSnackBar();
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('✅ Stations seeded successfully'),
            backgroundColor: AppColors.positive,
          ),
        );
      }
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).hideCurrentSnackBar();
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error: $e'),
            backgroundColor: AppColors.negative,
          ),
        );
      }
    }
  }
}
