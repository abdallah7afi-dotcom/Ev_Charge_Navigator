import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:ev_charge_navigator/theme/app_theme.dart';
import 'package:ev_charge_navigator/models/car_model.dart';
import 'package:ev_charge_navigator/services/auth_service.dart';
import 'package:ev_charge_navigator/services/firestore_service.dart';
import 'package:ev_charge_navigator/services/station_seed_service.dart';

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});

  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  final FirestoreService _firestoreService = FirestoreService();
  CarModel? _primaryCar;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    final authService = Provider.of<AuthService>(context, listen: false);
    if (!authService.isLoggedIn) return;

    try {
      final car = await _firestoreService.getPrimaryCar(authService.user!.uid);
      if (mounted) {
        setState(() {
          _primaryCar = car;
          _loading = false;
        });
      }
    } catch (e) {
      if (mounted) setState(() => _loading = false);
    }
  }

  void _showChangeEmailDialog() {
    final authService = Provider.of<AuthService>(context, listen: false);
    final currentEmailController =
        TextEditingController(text: authService.user?.email ?? '');
    final newEmailController = TextEditingController();
    String? errorText;

    showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setState) => AlertDialog(
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          title: Text('Change Email',
              style: GoogleFonts.inter(fontWeight: FontWeight.bold)),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: currentEmailController,
                readOnly: true,
                decoration: InputDecoration(
                  labelText: 'Current Email',
                  prefixIcon:
                      const Icon(Icons.email_outlined, color: Colors.grey),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12)),
                  filled: true,
                  fillColor: Colors.grey.shade100,
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: newEmailController,
                keyboardType: TextInputType.emailAddress,
                decoration: InputDecoration(
                  labelText: 'New Email',
                  prefixIcon:
                      const Icon(Icons.email, color: AppColors.primaryBlue),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12)),
                  errorText: errorText,
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child:
                  Text('Cancel', style: GoogleFonts.inter(color: Colors.grey)),
            ),
            ElevatedButton(
              onPressed: () async {
                if (newEmailController.text.trim().isEmpty) {
                  setState(() => errorText = 'Please enter a new email');
                  return;
                }
                final auth =
                    Provider.of<AuthService>(ctx, listen: false);
                final success =
                    await auth.updateEmail(newEmailController.text.trim());
                Navigator.pop(ctx);
                if (mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text(success
                          ? 'Verification email sent. Check your inbox.'
                          : auth.errorMessage ?? 'Error updating email'),
                      backgroundColor:
                          success ? AppColors.successGreen : AppColors.errorRed,
                    ),
                  );
                }
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.primaryBlue,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10)),
              ),
              child:
                  const Text('Save', style: TextStyle(color: Colors.white)),
            ),
          ],
        ),
      ),
    );
  }

  void _showChangePasswordDialog() {
    final oldPasswordController = TextEditingController();
    final newPasswordController = TextEditingController();
    final confirmPasswordController = TextEditingController();
    String? errorText;
    bool oldPasswordVerified = false;

    showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setState) => AlertDialog(
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          title: Text('Change Password',
              style: GoogleFonts.inter(fontWeight: FontWeight.bold)),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: oldPasswordController,
                obscureText: true,
                readOnly: oldPasswordVerified,
                decoration: InputDecoration(
                  labelText: 'Current Password',
                  prefixIcon: Icon(
                    oldPasswordVerified
                        ? Icons.check_circle
                        : Icons.lock_outline,
                    color: oldPasswordVerified
                        ? AppColors.successGreen
                        : AppColors.primaryBlue,
                  ),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12)),
                  filled: oldPasswordVerified,
                  fillColor:
                      oldPasswordVerified ? Colors.grey.shade100 : null,
                  errorText: !oldPasswordVerified ? errorText : null,
                ),
              ),
              if (!oldPasswordVerified) ...[
                const SizedBox(height: 12),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: () async {
                      if (oldPasswordController.text.isEmpty) {
                        setState(
                            () => errorText = 'Enter your current password');
                        return;
                      }
                      final auth =
                          Provider.of<AuthService>(ctx, listen: false);
                      final valid = await auth
                          .verifyPassword(oldPasswordController.text);
                      if (valid) {
                        setState(() {
                          oldPasswordVerified = true;
                          errorText = null;
                        });
                      } else {
                        setState(() => errorText = 'Incorrect password');
                      }
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.primaryBlue,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10)),
                    ),
                    child: const Text('Verify',
                        style: TextStyle(color: Colors.white)),
                  ),
                ),
              ],
              if (oldPasswordVerified) ...[
                const SizedBox(height: 12),
                TextField(
                  controller: newPasswordController,
                  obscureText: true,
                  decoration: InputDecoration(
                    labelText: 'New Password',
                    hintText: 'Min 6 characters',
                    prefixIcon:
                        const Icon(Icons.lock, color: AppColors.primaryBlue),
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12)),
                  ),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: confirmPasswordController,
                  obscureText: true,
                  decoration: InputDecoration(
                    labelText: 'Confirm New Password',
                    prefixIcon: const Icon(Icons.lock,
                        color: AppColors.primaryBlue),
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12)),
                    errorText: errorText,
                  ),
                ),
              ],
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child:
                  Text('Cancel', style: GoogleFonts.inter(color: Colors.grey)),
            ),
            if (oldPasswordVerified)
              ElevatedButton(
                onPressed: () async {
                  if (newPasswordController.text.length < 6) {
                    setState(() =>
                        errorText = 'Password must be at least 6 characters');
                    return;
                  }
                  if (newPasswordController.text !=
                      confirmPasswordController.text) {
                    setState(() => errorText = 'Passwords do not match');
                    return;
                  }
                  final auth =
                      Provider.of<AuthService>(ctx, listen: false);
                  final success =
                      await auth.updatePassword(newPasswordController.text);
                  Navigator.pop(ctx);
                  if (mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text(success
                            ? 'Password updated successfully!'
                            : auth.errorMessage ??
                                'Error updating password'),
                        backgroundColor: success
                            ? AppColors.successGreen
                            : AppColors.errorRed,
                      ),
                    );
                  }
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.primaryBlue,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10)),
                ),
                child: const Text('Update',
                    style: TextStyle(color: Colors.white)),
              ),
          ],
        ),
      ),
    );
  }

  Future<void> _seedStations() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: Text('Seed Stations',
            style: GoogleFonts.inter(fontWeight: FontWeight.bold)),
        content: Text(
          'This will delete all existing stations and add 29 Riyadh EV charging stations. Continue?',
          style: GoogleFonts.inter(fontSize: 14),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: Text('Cancel', style: GoogleFonts.inter(color: Colors.grey)),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(ctx, true),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.accentOrange,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10)),
            ),
            child: const Text('Seed', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );

    if (confirmed != true || !mounted) return;

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Seeding stations...'),
        duration: Duration(seconds: 30),
      ),
    );

    try {
      await _firestoreService.seedStations(
        StationSeedService.riyadhStations,
        onProgress: (current, total) {
          if (mounted) {
            ScaffoldMessenger.of(context).hideCurrentSnackBar();
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text('Added $current / $total stations...'),
                duration: const Duration(seconds: 30),
              ),
            );
          }
        },
      );

      if (mounted) {
        ScaffoldMessenger.of(context).hideCurrentSnackBar();
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('✅ Successfully seeded 29 stations!'),
            backgroundColor: AppColors.successGreen,
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).hideCurrentSnackBar();
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error seeding stations: $e'),
            backgroundColor: AppColors.errorRed,
          ),
        );
      }
    }
  }

  Future<void> _signOut() async {
    final authService = Provider.of<AuthService>(context, listen: false);
    await authService.signOut();
    if (mounted) {
      Navigator.pushNamedAndRemoveUntil(context, '/login', (route) => false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: Text('Settings',
            style: GoogleFonts.inter(fontWeight: FontWeight.w600)),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Profile Section
                  _buildSectionHeader('PROFILE'),
                  const SizedBox(height: 8),
                  _buildSettingTile(
                    Icons.email,
                    'Change Email',
                    'Update your email address',
                    onTap: _showChangeEmailDialog,
                  ),
                  _buildSettingTile(
                    Icons.lock,
                    'Change Password',
                    'Update your password',
                    onTap: _showChangePasswordDialog,
                  ),
                  const Divider(height: 32),

                  // My Cars Section
                  _buildSectionHeader('MY CARS'),
                  const SizedBox(height: 8),
                  _buildSettingTile(
                    Icons.directions_car,
                    'Manage Vehicles',
                    'Add or change your EV',
                    onTap: () =>
                        Navigator.pushNamed(context, '/car-selection'),
                  ),
                  if (_primaryCar != null) ...[
                    const SizedBox(height: 8),
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        gradient: AppGradients.cardGradient,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            _primaryCar!.name,
                            style: GoogleFonts.inter(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            '${_primaryCar!.connectorType} • ${_primaryCar!.batteryCapacity.toStringAsFixed(0)} kWh',
                            style: GoogleFonts.inter(
                              fontSize: 13,
                              color: Colors.white70,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                  const Divider(height: 32),

                  // App Section
                  _buildSectionHeader('APP'),
                  const SizedBox(height: 8),
                  _buildSettingTile(
                    Icons.cloud_upload,
                    'Seed Stations',
                    'Reset & add all 29 Riyadh stations',
                    iconColor: AppColors.accentOrange,
                    onTap: _seedStations,
                  ),
                  _buildSettingTile(
                    Icons.info,
                    'About App',
                    'Version and info',
                    onTap: () {
                      showAboutDialog(
                        context: context,
                        applicationName: 'EV Charge Navigator',
                        applicationVersion: '1.0.0',
                        applicationIcon: Container(
                          width: 48,
                          height: 48,
                          decoration: BoxDecoration(
                            color: AppColors.primaryBlue,
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: const Icon(Icons.ev_station,
                              color: Colors.white, size: 28),
                        ),
                        children: [
                          Text(
                            'Smart EV charging navigation app for Riyadh, Saudi Arabia. Find the nearest charging station, analyze battery range, and navigate with turn-by-turn directions.',
                            style: GoogleFonts.inter(fontSize: 14),
                          ),
                        ],
                      );
                    },
                  ),
                  const Divider(height: 32),

                  // Sign Out
                  const SizedBox(height: 8),
                  SizedBox(
                    width: double.infinity,
                    height: 52,
                    child: ElevatedButton.icon(
                      onPressed: _signOut,
                      icon: const Icon(Icons.logout),
                      label: Text(
                        'Sign Out',
                        style: GoogleFonts.inter(
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.errorRed,
                        foregroundColor: Colors.white,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 32),
                ],
              ),
            ),
    );
  }

  Widget _buildSectionHeader(String title) {
    return Text(
      title,
      style: GoogleFonts.inter(
        fontSize: 12,
        fontWeight: FontWeight.bold,
        color: AppColors.textSecondary,
        letterSpacing: 1.2,
      ),
    );
  }

  Widget _buildSettingTile(
    IconData icon,
    String title,
    String subtitle, {
    Color? iconColor,
    VoidCallback? onTap,
  }) {
    return ListTile(
      contentPadding: EdgeInsets.zero,
      leading: Container(
        width: 40,
        height: 40,
        decoration: BoxDecoration(
          color: (iconColor ?? AppColors.primaryBlue).withValues(alpha: 0.1),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Icon(icon, color: iconColor ?? AppColors.primaryBlue, size: 22),
      ),
      title: Text(
        title,
        style: GoogleFonts.inter(fontSize: 15, fontWeight: FontWeight.w600),
      ),
      subtitle: Text(
        subtitle,
        style: GoogleFonts.inter(fontSize: 12, color: AppColors.textSecondary),
      ),
      trailing: const Icon(Icons.chevron_right, color: AppColors.textSecondary),
      onTap: onTap,
    );
  }
}
