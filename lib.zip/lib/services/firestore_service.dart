import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:ev_charge_navigator/models/car_model.dart';
import 'package:ev_charge_navigator/models/station_model.dart';
import 'package:ev_charge_navigator/models/review_model.dart';

class FirestoreService {
  final FirebaseFirestore _db = FirebaseFirestore.instance;

  // ── User Operations ──

  Future<Map<String, dynamic>?> getUser(String uid) async {
    try {
      final doc = await _db.collection('users').doc(uid).get();
      if (doc.exists) {
        return doc.data();
      }
      return null;
    } catch (e) {
      throw Exception('Error fetching user: $e');
    }
  }

  // ── Car Operations ──

  Future<void> saveCar(String uid, CarModel car) async {
    try {
      final carId = car.name.replaceAll(' ', '_').toLowerCase();
      await _db
          .collection('users')
          .doc(uid)
          .collection('cars')
          .doc(carId)
          .set(car.toMap());
    } catch (e) {
      throw Exception('Error saving car: $e');
    }
  }

  Future<List<CarModel>> getUserCars(String uid) async {
    try {
      final snapshot =
          await _db.collection('users').doc(uid).collection('cars').get();
      return snapshot.docs
          .map((doc) => CarModel.fromMap(doc.data(), doc.id))
          .toList();
    } catch (e) {
      throw Exception('Error fetching cars: $e');
    }
  }

  Future<CarModel?> getPrimaryCar(String uid) async {
    try {
      final snapshot = await _db
          .collection('users')
          .doc(uid)
          .collection('cars')
          .limit(1)
          .get();
      if (snapshot.docs.isEmpty) return null;
      return CarModel.fromMap(snapshot.docs.first.data(), snapshot.docs.first.id);
    } catch (e) {
      throw Exception('Error fetching primary car: $e');
    }
  }

  // ── Station Operations ──

  Future<List<StationModel>> getAllStations() async {
    try {
      final snapshot = await _db.collection('stations').get();
      return snapshot.docs
          .map((doc) => StationModel.fromMap(doc.data(), doc.id))
          .toList();
    } catch (e) {
      throw Exception('Error fetching stations: $e');
    }
  }

  Future<void> seedStations(
    List<Map<String, dynamic>> stations, {
    Function(int current, int total)? onProgress,
  }) async {
    try {
      // Delete existing stations
      final existing = await _db.collection('stations').get();
      for (final doc in existing.docs) {
        await doc.reference.delete();
      }

      // Add new stations
      for (int i = 0; i < stations.length; i++) {
        await _db.collection('stations').add(stations[i]);
        onProgress?.call(i + 1, stations.length);
      }
    } catch (e) {
      throw Exception('Error seeding stations: $e');
    }
  }

  // ── Review Operations ──

  Future<void> addReview(String stationId, ReviewModel review) async {
    try {
      await _db
          .collection('stations')
          .doc(stationId)
          .collection('reviews')
          .add(review.toMap());
    } catch (e) {
      throw Exception('Error adding review: $e');
    }
  }

  Future<List<ReviewModel>> getStationReviews(String stationId) async {
    try {
      final snapshot = await _db
          .collection('stations')
          .doc(stationId)
          .collection('reviews')
          .orderBy('createdAt', descending: true)
          .get();
      return snapshot.docs
          .map((doc) => ReviewModel.fromMap(doc.data(), doc.id))
          .toList();
    } catch (e) {
      return [];
    }
  }

  Future<double> getStationAverageRating(String stationId) async {
    try {
      final reviews = await getStationReviews(stationId);
      if (reviews.isEmpty) return 0.0;
      final total = reviews.fold(0.0, (acc, r) => acc + r.rating);
      return total / reviews.length;
    } catch (e) {
      return 0.0;
    }
  }

  Future<bool> hasUserReviewed(String stationId, String userId) async {
    try {
      final snapshot = await _db
          .collection('stations')
          .doc(stationId)
          .collection('reviews')
          .where('userId', isEqualTo: userId)
          .limit(1)
          .get();
      return snapshot.docs.isNotEmpty;
    } catch (e) {
      return false;
    }
  }

  Future<void> updateUserEmail(String uid, String email) async {
    try {
      await _db.collection('users').doc(uid).update({'email': email});
    } catch (e) {
      throw Exception('Error updating email: $e');
    }
  }
}
